FreeOO.in — Company Website
============================

WHAT'S INSIDE
--------------
index.html            Home / company profile page
about.html            About Us page
contact.html          Contact Us page (form + details)
privacy-policy.html   Privacy Policy
disclaimer.html       Disclaimer
css/style.css         All styling, colours, fonts, animations
js/script.js          Navigation menu, scroll animations, 3D tilt effects, contact form

HOW TO UPLOAD
--------------
This is a plain static site — no build step, no server-side code required.

1. Upload all files and folders exactly as they are (keep "css" and "js"
   folders alongside the .html files — don't rename them).
2. On most hosting (cPanel, Hostinger, GitHub Pages, Netlify, etc.) just
   drop everything into the public/www/root folder.
3. Open index.html in a browser to confirm it works before going live.

That's it — no npm install, no database, no PHP needed.

ABOUT THE FONT
--------------
You asked for "Google Sans" — Google does not publish this font for public
web use (it's a system font on some Android/Pixel/Chrome OS devices only).
The site is set up to use real Google Sans automatically on any device
that already has it installed, and falls back to "Poppins Light" — the
closest free alternative — everywhere else, so the look stays consistent
for all visitors. This is set in css/style.css under the --font variable
if you ever want to change it.

THE CONTACT FORM
------------------
Since this is a static site with no backend, the Contact form on
contact.html works by opening the visitor's own email app with the
message pre-filled, addressed to freeoo.in@gmail.com. No server, API key,
or monthly form service needed. If you later want messages to submit
silently without opening an email app, you'd connect the form to a
service like Formspree, Web3Forms, or your own backend — happy to wire
that up if you want it.

A FEW THINGS TO DOUBLE-CHECK / PERSONALISE
--------------------------------------------
- "Response time" on the Contact page currently says 2–3 business days —
  change in contact.html if your actual turnaround differs.
- Page text mentions 6 apps + "more on the way" — when you publish a new
  app, duplicate one .app-card block in index.html and update the icon,
  name, description and tag.
- Favicon is a simple generated "F" mark (no image file needed) — swap
  the <link rel="icon"> line in each page if you design a proper logo.
- Legal pages (privacy-policy.html, disclaimer.html) are solid generic
  templates written for an app-development company, but for a fully
  watertight legal review (especially before scaling up data collection,
  ads, or in-app payments), it's worth having a lawyer glance over them.

DESIGN NOTES
------------
Colour palette: white base with soft indigo/violet gradient accents
(--indigo / --violet in style.css), kept light throughout per your brief.
The animated "floating app constellation" in the hero tilts toward the
cursor on desktop (3D perspective + parallax) for the "4D" feel you
asked for; app cards also tilt slightly and show a soft light-spotlight
on hover. Everything respects prefers-reduced-motion for accessibility,
and the whole layout is responsive from small phones up through large
desktop screens.
