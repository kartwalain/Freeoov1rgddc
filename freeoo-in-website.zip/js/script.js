/* =========================================================
   FreeOO.in — Shared interactions
   ========================================================= */

document.addEventListener('DOMContentLoaded', function () {

  /* ---- Footer year ---- */
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---- Navbar scroll state ---- */
  var navbar = document.querySelector('.navbar');
  function onScroll () {
    if (!navbar) return;
    if (window.scrollY > 12) navbar.classList.add('scrolled');
    else navbar.classList.remove('scrolled');
  }
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  /* ---- Mobile menu ---- */
  var toggle = document.querySelector('.nav-toggle');
  var panel = document.querySelector('.mobile-panel');
  var scrim = document.querySelector('.scrim');

  function closeMenu () {
    if (toggle) toggle.classList.remove('open');
    if (panel) panel.classList.remove('open');
    if (scrim) scrim.classList.remove('open');
    document.body.style.overflow = '';
  }
  function openMenu () {
    if (toggle) toggle.classList.add('open');
    if (panel) panel.classList.add('open');
    if (scrim) scrim.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  if (toggle) {
    toggle.addEventListener('click', function () {
      var isOpen = panel && panel.classList.contains('open');
      if (isOpen) closeMenu(); else openMenu();
    });
  }
  if (scrim) scrim.addEventListener('click', closeMenu);
  if (panel) {
    panel.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', closeMenu);
    });
  }

  /* ---- Scroll reveal ---- */
  var revealEls = document.querySelectorAll('.reveal, .reveal-stagger');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  /* ---- Hero constellation 3D tilt-toward-cursor ---- */
  var hero = document.querySelector('.hero');
  var stage = document.querySelector('.const-stage');
  if (hero && stage && window.matchMedia('(pointer: fine)').matches) {
    var rafId = null;
    var targetX = 0, targetY = 0, curX = 0, curY = 0;

    hero.addEventListener('mousemove', function (e) {
      var rect = hero.getBoundingClientRect();
      var px = (e.clientX - rect.left) / rect.width - 0.5;
      var py = (e.clientY - rect.top) / rect.height - 0.5;
      targetX = px * 18;
      targetY = py * -18;
      if (!rafId) rafId = requestAnimationFrame(tick);
    });
    hero.addEventListener('mouseleave', function () {
      targetX = 0; targetY = 0;
      if (!rafId) rafId = requestAnimationFrame(tick);
    });

    function tick () {
      curX += (targetX - curX) * 0.08;
      curY += (targetY - curY) * 0.08;
      stage.style.transform = 'rotateY(' + curX + 'deg) rotateX(' + curY + 'deg)';
      if (Math.abs(targetX - curX) > 0.05 || Math.abs(targetY - curY) > 0.05) {
        rafId = requestAnimationFrame(tick);
      } else {
        rafId = null;
      }
    }
  }

  /* ---- App card spotlight + subtle tilt ---- */
  var cards = document.querySelectorAll('.app-card:not(.soon)');
  if (window.matchMedia('(pointer: fine)').matches) {
    cards.forEach(function (card) {
      card.addEventListener('mousemove', function (e) {
        var rect = card.getBoundingClientRect();
        var x = e.clientX - rect.left;
        var y = e.clientY - rect.top;
        card.style.setProperty('--mx', x + 'px');
        card.style.setProperty('--my', y + 'px');
        var rx = ((y / rect.height) - 0.5) * -6;
        var ry = ((x / rect.width) - 0.5) * 6;
        card.style.transform = 'translateY(-8px) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg)';
      });
      card.addEventListener('mouseleave', function () {
        card.style.transform = '';
      });
    });
  }

  /* ---- Contact form -> mailto ---- */
  var form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = form.name.value.trim();
      var email = form.email.value.trim();
      var topic = form.topic ? form.topic.value : '';
      var message = form.message.value.trim();
      var status = document.getElementById('formStatus');

      if (!name || !email || !message) {
        if (status) {
          status.textContent = 'Please fill in your name, email, and message before sending.';
          status.style.color = '#e2543a';
          status.classList.add('show');
        }
        return;
      }

      var subject = encodeURIComponent('[FreeOO.in] ' + (topic || 'Website Enquiry') + ' — ' + name);
      var body = encodeURIComponent(
        'Name: ' + name + '\n' +
        'Email: ' + email + '\n' +
        'Topic: ' + (topic || 'General') + '\n\n' +
        'Message:\n' + message
      );
      window.location.href = 'mailto:freeoo.in@gmail.com?subject=' + subject + '&body=' + body;

      if (status) {
        status.textContent = 'Your email app should open with this message ready to send. If it doesn\'t, write to us directly at freeoo.in@gmail.com.';
        status.style.color = '#19a387';
        status.classList.add('show');
      }
    });
  }

});
